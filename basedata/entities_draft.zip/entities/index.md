# menu: Entidades

Methods for working with the Products section. All methods of this section begin with “menu.”

📝 [Editar Documento](https://github.com/4uRest/documentation)