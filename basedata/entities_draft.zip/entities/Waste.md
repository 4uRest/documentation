# Merma

Entidad utilizada para clasificar/agrupar .

### **Tabla en base de datos.**


Diagrama de la base de datos [(Link aquí)](https://app.diagrams.net/#G1TR1Q9nC36PcOae7jeaJIxgDLTjUUpkfL).

### **Descripción de campos.**

El detalle de los campos de la tabla en la base de datos son:


📝 [Editar Documento](https://github.com/4uRest/documentation)